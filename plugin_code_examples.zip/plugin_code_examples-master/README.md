# QGIS3.0_Start
你可以同时在 github 下载， https://github.com/water-law/QGIS3.0_Start -> Clone or download -> doanload zip


plugin_code_examples.7z: 这是一个入门的例子， 运行在 VS2015/VS2017 集成环境中。

项目配置： QGIS3.0 + Qt5 + OSGeo4W

IDE： VS2017


QGIS3.0 + OSGeo4W: 官网下载安装， https://www.qgis.org/en/site/forusers/download.html

QGIS3.0 安装较为简单不多说。OSGeo4W:  选择高级安装， 安装 lib:  qt5-devel, qgis-devel

Qt: http://download.qt.io/archive/qt/    选择对应版本， 我是 Qt5.10.0,  进入到 http://download.qt.io/archive/qt/5.10/5.10.0/qt-opensource-windows-x86-5.10.0.exe

安装 Qt

配置下 Qt 的path环境变量：C:\Qt\Qt5.10.0\5.10.0\msvc2015_64\bin;C:\Qt\Qt5.10.0\Tools\QtCreator\bin

VS2017 开发环境配置：

菜单栏的工具->扩展和更新->联机： 搜索 Qt VS TOOL,  安装后重启 VS2017。

解决方案右键属性:  VC++ 目录->包含目录添加 C:\OSGeo4W64\apps\qgis\include，C:\OSGeo4W64\include。具体看个人的 OSGeo4W64 安装目录。
VC++ 目录->库目录添加 C:\OSGeo4W64\apps\qgis\lib， 具体看个人的 OSGeo4W64 安装目录。
链接器-> 常规->附加库目录添加 $(QTDIR)\lib， lib 下的 dll 库项目链接时会用到。

Qt VS Tool -> Qt Options -> Qt Versions： 添加 Qt5,  路径C:\OSGeo4W64\apps\Qt5,  具体看个人的 OSGeo4W64 安装目录。

根据需要选择配置：
链接器 -> 输入-> 附加依赖项依次添加：qgis_app.lib，qgis_core.lib，qgis_gui.lib ,  这些依赖项位于 C:\OSGeo4W64\apps\qgis\lib， 具体看个人的 OSGeo4W64 安装目录。
