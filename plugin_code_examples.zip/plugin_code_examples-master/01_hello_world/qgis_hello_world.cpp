#include "qgis_hello_world.h"
#include <QMessageBox>
#include <qtextcodec.h>
#include <QFileDialog>
#include <qgsmaplayerstore.h>
#include <qgslogger.h>
#include <qgslayertreemodel.h>
#include <qgsproject.h>
#include <QGridLayout>
#include <QtDebug>
#include <qgsvectorlayercache.h>
#include <qgsattributetableview.h>
#include <qgsattributetablemodel.h>
#include <qgsattributetablefiltermodel.h>
#include "ui_qgsattributetabledialog.h"
#include <qgsrenderer.h>
#include <qgssinglesymbolrenderer.h>
#include <qgssymbol.h>
#include <qgsvectordataprovider.h>
#include <QFile>
#include <qgsproject.h>
#include <qgseditformconfig.h>
#include <qgsdatasourceuri.h>
#include <qgsfields.h>
#include <qgsdefaultvalue.h>
#include <qapplication.h>
#include <qtranslator.h>


const QString HelloWorldPlugin::s_name = QObject::tr("Hello World Plugin");
const QString HelloWorldPlugin::s_description = QObject::tr("Sample Plugin");
const QString HelloWorldPlugin::s_category = QObject::tr("Plugins");
const QString HelloWorldPlugin::s_version = QObject::tr("Version 5.2.0");
const QString HelloWorldPlugin::s_icon = "";
const QgisPlugin::PluginType HelloWorldPlugin::s_type = QgisPlugin::UI;

QGISEXTERN QgisPlugin* classFactory(QgisInterface* qgis_if)
{
   std::cout << "::classFactory" << std::endl;
   return new HelloWorldPlugin(qgis_if);
}

QGISEXTERN QString name()
{
   std::cout << "::name" << std::endl;
   return HelloWorldPlugin::s_name;
}

QGISEXTERN QString description()
{
   std::cout << "::description" << std::endl;
   return HelloWorldPlugin::s_description;
}

QGISEXTERN QString category()
{
   std::cout << "::category" << std::endl;
   return HelloWorldPlugin::s_category;
}

QGISEXTERN int type()
{
   std::cout << "::type" << std::endl;
   return HelloWorldPlugin::s_type;
}

QGISEXTERN QString version()
{
   std::cout << "::version" << std::endl;
   return HelloWorldPlugin::s_version;
}

QGISEXTERN QString icon()
{
   std::cout << "::icon" << std::endl;
   return HelloWorldPlugin::s_icon;
}

QGISEXTERN void unload(QgisPlugin* plugin)
{
   std::cout << "::unload" << std::endl;
   delete plugin;
}


/*virtual*/ void HelloWorldPlugin::initGui()
{
   std::cout << "HelloWorldPlugin::initGui" << std::endl;

   // add an action to the menu
   m_action = new QAction(QIcon("" ), tr("Mark Point"), this);
   m_action->setText(tr("Mark Point"));
   m_action->setWhatsThis(tr("Draw on the map canvas."));

   connect(m_action, SIGNAL(triggered(bool)), this, SLOT(run(bool)));
   m_qgis_if->addRasterToolBarIcon(m_action);
   m_qgis_if->addPluginToMenu(tr("&Mark Point"), m_action);
}


void HelloWorldPlugin::run(bool checked)
{
	QCoreApplication* app = QApplication::instance();
	QTranslator* translator = new QTranslator();
	translator->load("");
	app->installTranslator(translator);
	QgsDataSourceUri uri = QgsDataSourceUri::QgsDataSourceUri();
	uri.setConnection("localhost", "5432", "place", "postgres", "postgres");
	uri.setDataSource("public", "objnam", "geom");
	qDebug() << uri.uri(true);
	QgsVectorLayer* vectorLayer = m_qgis_if->addVectorLayer(uri.uri(false), QString::fromLocal8Bit("���"), "postgres");
	QgsEditFormConfig formConfig = vectorLayer->editFormConfig();
	QgsFields fields = vectorLayer->fields();
	QStringList fieldNames = fields.names();
	Q_FOREACH(QString fieldName, fieldNames)
	{
		qint64 fieldIndex = fields.indexFromName(fieldName);
	}
	QFile styleFile("E:/projects/Zoomer/attributeform/Attribute_Form.ui");
	QFile styleFile2("E:/projects/plugin_code_examples/vstudio/01_hello_world/attribute_form.py");
	formConfig.setUiForm(styleFile.fileName());
	formConfig.setInitCodeSource(QgsEditFormConfig::CodeSourceFile);
	formConfig.setInitFilePath(styleFile2.fileName());
	qDebug() << styleFile.fileName();
	formConfig.setInitFunction("formOpen");
	//formConfig.setReadOnly(0, true);
	//formConfig.setLabelOnTop(0, true);
	//formConfig.clearTabs();
	//formConfig.setLayout(QgsEditFormConfig::EditorLayout::TabLayout);
	vectorLayer->setEditFormConfig(formConfig);
}